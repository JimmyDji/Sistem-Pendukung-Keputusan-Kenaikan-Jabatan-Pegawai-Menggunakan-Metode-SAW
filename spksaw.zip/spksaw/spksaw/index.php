<?php
session_start();
require_once "config.php";
if (!isset($_SESSION["is_logged"])) {
  header('location: login.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SPK-Pemilihan Aparat Desa</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="dist/sweetalert2.min.css">
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/jquery.chained.min.js"></script>
    <style>
        body {
            margin-top: 40px;
        }
        .footer{
            background-color: rgba(0,0,0,0.80);
            background-size: 100%;
            width: auto;
            height: auto;
            color: white;
            font-family: arial black;
        }
        .drop{
            width: 300px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand" href="#">SPK-PEMILIHAN APARAT DESA</a> 
                </div>
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="?page=home" style="font-weight: bold; color: darkred;">Beranda <span class="sr-only">(current)</span></a></li>
                        <li class="dropdown">
                          <a href="#" class="dropdown-toggle" style="font-weight: bold; color: darkred;" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" >Perhitungan<span class="caret"></span></a>
                          <ul class="dropdown-menu">
                            <?php $query = $connection->query("SELECT * FROM jabatan"); while ($row = $query->fetch_assoc()): ?>
                              <li><a href="?page=perhitungan&jabatan=<?=$row["kd_jabatan"]?>"><?=$row["nama"]?></a></li>
                            <?php endwhile; ?>
                          </ul>
                        </li>
                        <li class="dropdown">
                          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" style="font-weight: bold; color: darkred;">Input <span class="caret" ></span></a>
                          <ul class="dropdown-menu">
                            <li><a href="?page=jabatan">Data Jabatan</a></li>
                            <li class="divider"></li>
                            <li><a href="?page=pegawai">Data Pegawai</a></li>
                            <li><a href="?page=kriteria">Kriteria</a></li>
                            <li><a href="?page=model">Model</a></li>
                            <li><a href="?page=penilaian">Penilaian</a></li>
                            <li class="divider"></li>
                            <li><a href="?page=nilai">Persyaratan</a></li>
                          </ul>
                        </li>
                        <li class="dropdown">
                          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" style="font-weight: bold; color: darkred;">Laporan<span class="caret" style="font-weight: bold; color: darkred;"></span></a>
                          <ul class="dropdown-menu">
                            <li><a href="?page=lap_seluruh">Seluruh Pegawai</a></li>
                            <li><a href="?page=lap_perpegawai">Per Pegawai</a></li>
                            <li><a href="?page=lap_pendaftaran">Pendaftaran</a></li>
                          </ul>
                        </li>
                        <li><a href="?page=pengumuman" style="font-weight: bold; color: darkred;">Pengumuman</a></li>
                        <li><a href="#">|</a></li>
                        <li class="dropdown">
                          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" style="font-weight: bold; color: red;"> <?= ucfirst($_SESSION["username"]) ?></a>
                          <ul class="dropdown-menu">
                            <center>
                                <br>
                            <li><img src="1.png" width="100" height="100" style="border : 50%;"></li>
                            <br>
                            <table class="drop" align="center">
                                <tr>
                                    <td><a href="ubahpass.php" class="btn btn-default" style="width: 100px; ">PROFIL</a></td>
                                    <td width="10px">  </td>
                                    <td><a href="logout.php" class="btn btn-default" style="width: 100px; ">LOGOUT</a></td>
                                </tr>
                            </table>
                            <br>
                                
                            </center>
                          </ul>

                    </ul>
                </div><!-- /.navbar-collapse -->
            </div><!-- /.container-fluid -->
        </nav>
        <div class="row">
            <div class="col-md-12">
              <?php include page($_PAGE); ?>
            </div>
        </div>
    </div>
    <div class="footer">
        <br>
        <table>
            <tr>
                <td> <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d31552.8302739565!2d121.6188488!3d-8.68168!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2db29e078cbf6489%3A0x41ffa0475a61238b!2sBoafeo%2C%20Maukaro%2C%20Kabupaten%20Ende%2C%20Nusa%20Tenggara%20Tim.%2C%20Indonesia!5e0!3m2!1sid!2sus!4v1624290674157!5m2!1sid!2sus" width="600" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe></td>
                <td width="60px">
                </td>
                <td style="font-family: Bookman Old Style ">
                    <center> <h3>
                    PEMERINTAH KABUPATEN ENDE <br>
                    KECAMATAN MAUKARO  <br>
                    DESA BOAFEO <br>
                    Jl. Trans Nangaba - Maukaro <br>
                    ___________________________________ <br> </h3>
                    <h4 style="font-family: Monotype Corsiva;" >powered by: <a href="https://linktr.ee/jimmy_dji9910" target="blank" style="text-decoration: none; color: yellow; font-family: Monotype Corsiva;">@jimmy_dji9910</a></h4>
                    </center>
                </td>
                <td width="60px">
                </td>
                <td>
                    <img src="image/a.png" width="100px" height="120px">
                </td>
            </tr>
        </table>
       
        <br>
    </div>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="dist/sweetalert2.min.js"></script>
</body>
</html>
