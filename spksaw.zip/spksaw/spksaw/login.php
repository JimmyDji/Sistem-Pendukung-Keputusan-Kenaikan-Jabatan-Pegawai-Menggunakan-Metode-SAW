<!DOCTYPE html>
</style>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SPK-Kenaikan Jabatan</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="dist/sweetalert2.min.css">
    <style>
        body {
            display: grid;
            margin-top: 40px;
            background-image: url(a.jpg);
        }
        Swal.fire{
            font-size: 90px;
        }
    </style>

</head>
<body>
    </div>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="dist/sweetalert2.min.js"></script>
</body>
</html>
    <br><br><br><br>
    <div class="container">
        <div class="row">
            <div class="col-md-4"></div>
            <div class="col-md-4">
                <div class="panel panel-primary">
                    <div class="panel-heading"><h3 class="text-center">LOGIN ADMIN</h3>
                    <marquee>SISTEM PENDUKUNG KEPUTUSAN PEMILIHAN APARAT DESA DI DESA BOAFEO, KECAMATAN MAUKARO, KABUPATEN ENDE </marquee></div>
                    <div class="panel-body">
                        <form action="<?=$_SERVER['REQUEST_URI']?>" method="POST">
                            <div class="form-group">
                                <label for="username">Nama Pengguna</label>
                                <input type="text" name="username" class="form-control" id="username" placeholder="Masukan Nama Pengguna Anda" autofocus="on">
                            </div>
                            <div class="form-group">
                                <label for="password">Kata Sandi</label>
                                <input type="password" name="password" class="form-control" id="password" placeholder="Masukan Kata Sandi Anda">
                            </div> <br>
                            <center>
                            <button type="submit" class="btn btn-primary" style="width:100%;"><b>MASUK</b></button>
                            <br><br>
                            </center>
                        </form>

                    </div>
                </div>
            </div>
            <div class="col-md-4"></div>
        </div>
    </div>
    <br><br><br><br>
</body>
</html>

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    require_once "config.php";

    $sql = "SELECT * FROM pengguna WHERE username='$_POST[username]' AND password='" . md5($_POST['password']) . "'";
    if ($query = $connection->query($sql)) {
        if ($query->num_rows) {
            session_start();
            while ($data = $query->fetch_array()) {
                $_SESSION["is_logged"] = true;
                $_SESSION["username"] = $data["username"];
                $_SESSION["status"] = "petugas";
                
              }
            header('location: index.php');
        } else {
            echo '';?>
            <script>
            Swal.fire({
               icon: 'error',
               title: 'Oops...',
               text: 'Username Dan Password Tidak Sesuai!',
            })
            </script> <?php

        }
    } else {
        echo "Query error!";
    }
}
?>