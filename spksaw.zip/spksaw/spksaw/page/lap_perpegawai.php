<div class="row">
	<div class="col-md-12">
	    <div class="panel panel-primary">
	        <div class="panel-heading"><h3 class="text-center">Laporan Nilai Pegawai 
	        	</h3></div>
	        <div class="panel-body">
							<form class="form-inline" action="<?=$_SERVER["REQUEST_URI"]?>" method="post">
								<label for="peg">Pegawai :</label>
								<select class="form-control" name="peg">
									<option> --- </option>
									<?php $q = $connection->query("SELECT * FROM pegawai WHERE nip IN(SELECT nip FROM hasil)"); while ($r = $q->fetch_assoc()): ?>
										<option value="<?=$r["nip"]?>"><?=$r["nip"]?> | <?=$r["nama"]?></option>
									<?php endwhile; ?>
								</select>
								<button type="submit" class="btn btn-primary">Tampilkan</button>
							</form>
	            <?php if ($_SERVER["REQUEST_METHOD"] == "POST"): ?>
								<?php
								$q = $connection->query("SELECT b.kd_jabatan, b.nama, h.nilai, (SELECT MAX(nilai) FROM hasil WHERE nip=h.nip) AS nilai_max FROM pegawai m JOIN hasil h ON m.nip=h.nip JOIN jabatan b ON b.kd_jabatan=h.kd_jabatan WHERE m.nip=$_POST[peg]");
								$jabatan = []; $data = [];
								while ($r = $q->fetch_assoc()) {
									$jabatan[$r["kd_jabatan"]] = $r["nama"];
									$data[$r["kd_jabatan"]][] = $r["nilai"];
									$max = $r["nilai_max"];
								}
								?>
								<hr>
								<table class="table table-condensed">
									<tbody>
										<?php $query = $connection->query("SELECT DISTINCT(p.kd_jabatan), k.nama, n.nilai FROM nilai n JOIN penilaian p USING(kd_kriteria) JOIN kriteria k USING(kd_kriteria) WHERE n.nip=$_POST[peg] AND n.kd_jabatan=1"); while ($r = $query->fetch_assoc()): ?>
											<tr>
												<th><?=$r["nama"]?></th>
												<td>: <?=number_format($r["nilai"], 8)?></td>
											</tr>
										<?php endwhile; ?>
									</tbody>
								</table>
								<hr>
								<table class="table table-condensed">
		                <thead>
		                    <tr>
							<?php foreach ($jabatan as $key => $val): ?>
			                <th><?=$val?></th>
							<?php endforeach; ?>
							<th>Nilai Maksimal </th>
		                    </tr>
		                </thead>
		                <tbody>
							<tr>
                        <?php foreach($jabatan as $key => $val): ?>
	                        <?php foreach($data[$key] as $v): ?>
							<td><?=number_format($v, 8)?></td>
							<?php endforeach ?>
							<?php endforeach ?>
							<td><?=number_format($max, 8)?></td>
						</tr>
		                </tbody>
		            </table>
	            <?php endif; ?>
	        </div>
	        <br><br><br><br>
	    </div>
	</div>
</div>
