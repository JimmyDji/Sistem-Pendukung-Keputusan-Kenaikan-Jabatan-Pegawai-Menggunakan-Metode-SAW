<?php
$update = (isset($_GET['action']) AND $_GET['action'] == 'update') ? true : false;
if ($update) {
    $sql = $connection->query("SELECT * FROM tbl_soal WHERE id_soal='$_GET[key]'");
    $row = $sql->fetch_assoc();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $validasi = false; $err = false;
    if ($update) {
        $sql = "UPDATE tbl_soal SET soal='$_POST[soal]',a='$_POST[a]',b='$_POST[b]',c='$_POST[c]',d='$_POST[d]',kunci='$_POST[kunci]',tanggal='$_POST[tanggal]',aktif='$_POST[aktif]' WHERE id_soal='$_GET[key]'";
    } else {
        $sql = "INSERT INTO tbl_soal VALUES (NULL, '$_POST[soal]','$_POST[a]','$_POST[b]','$_POST[c]','$_POST[d]','$_POST[kunci]','$_POST[tanggal]','$_POST[aktif]' )";
        $validasi = true;
    }

    if ($validasi) {
        $q = $connection->query("SELECT id_soal FROM tbl_soal WHERE soal LIKE '%$_POST[soal]%'");
        if ($q->num_rows) {
            echo alert("Pertanyaan sudah ada!", "?page=pertanyaan");
            $err = true;
        }
    }

  if (!$err AND $connection->query($sql)) {
    echo alert("Berhasil!", "?page=pertanyaan");
  } else {
        echo alert("Gagal!", "?page=pertanyaan");
  }
}

if (isset($_GET['action']) AND $_GET['action'] == 'delete') {
  $connection->query("DELETE FROM tbl_soal WHERE id_soal='$_GET[key]'");
    echo alert("Berhasil!", "?page=pertanyaan");
}
?>
<div class="row">
    <div class="col-md-4">
        <div class="panel panel-<?= ($update) ? "danger" : "primary" ?>">
            <div class="panel-heading"><h3 class="text-center"><?= ($update) ? "EDIT PERTANYAAN" : "TAMBAH PERTANYAAN" ?></h3></div>
            <div class="panel-body">
                <form action="<?=$_SERVER['REQUEST_URI']?>" method="POST">
                    <div class="form-group">
                        <label for="soal">Pertanyaan</label>
                        <input type="text" name="soal" class="form-control" <?= (!$update) ?: 'value="'.$row["soal"].'"' ?>>
                    </div>
                    <div class="form-group">
                        <label for="a">Pilihan Ganda A</label>
                        <input type="text" name="a" class="form-control" <?= (!$update) ?: 'value="'.$row["a"].'"' ?>>
                    </div>
                    <div class="form-group">
                        <label for="b">Pilihan Ganda B</label>
                        <input type="text" name="b" class="form-control" <?= (!$update) ?: 'value="'.$row["b"].'"' ?>>
                    </div>
                    <div class="form-group">
                        <label for="c">Pilihan Ganda C</label>
                        <input type="text" name="c" class="form-control" <?= (!$update) ?: 'value="'.$row["c"].'"' ?>>
                    </div>
                    <div class="form-group">
                        <label for="d">Pilihan Ganda D</label>
                        <input type="text" name="d" class="form-control" <?= (!$update) ?: 'value="'.$row["d"].'"' ?>>
                    </div>
                    <div class="form-group">
                    <label for="kunci">Jawaban Yang Benar</label>
                    <select class="form-control" name="kunci">
                        <option>---</option>
                        <option value="a">A.  <?=$row['a']?></option>
                        <option value="b">B.  <?=$row['b']?></option>
                        <option value="c">C.  <?=$row['c']?></option>
                        <option value="d">D.  <?=$row['d']?></option>
                    </select>
                    </div>
                    <div class="form-group">
                        <label for="tanggal">Tanggal</label>
                        <input type="date" name="tanggal" class="form-control" <?= (!$update) ?: 'value="'.$row["tanggal"].'"' ?>>
                    </div>
                    <select class="form-control" name="aktif">
                        <option>---</option>
                        <option value="Y">Aktif (Y)</option>
                        <option value="N">Tidak Aktif (N)</option>
                    </select>
                    <br>
                    <button type="submit" class="btn btn-<?= ($update) ? "warning" : "primary" ?> btn-block">Simpan</button>
                    <?php if ($update): ?>
                        <a href="?page=pertanyaan" class="btn btn-danger btn-block">Batal</a>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </div>
    <div class="col-md-8">
        <div class="panel panel-primary">
            <div class="panel-heading"><h3 class="text-center">DAFTAR PERTANYAAN</h3></div>
            <div class="panel-body">
                <table class="table table-condensed">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Pertanyaan</th>
                            <th>A</th>
                            <th>B</th>
                            <th>C</th>
                            <th>D</th>
                            <th>Kunci</th>
                            <th>Tanggal</th>
                            <th>Aktif</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; ?>
                        <?php if ($query = $connection->query("SELECT * FROM tbl_soal")): ?>
                            <?php while($row = $query->fetch_assoc()): ?>
                            <tr>
                                <td><?=$no++?></td>
                                <td><?=$row['soal']?></td>
                                <td><?=$row['a']?></td>
                                <td><?=$row['b']?></td>
                                <td><?=$row['c']?></td>
                                <td><?=$row['d']?></td>
                                <td><?=$row['kunci']?></td>
                                <td><?=$row['tanggal']?></td>
                                <td><?=$row['aktif']?></td>
                                <td>
                                    <div class="btn-group">
                                        <a href="?page=pertanyaan&action=update&key=<?=$row['id_soal']?>" class="btn btn-warning btn-xs" style="width: 60px; ">Edit</a>
                                        <a href="?page=pertanyaan&action=delete&key=<?=$row['id_soal']?>" class="btn btn-danger btn-xs" style="width: 60px; ">Hapus</a>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile ?>
                        <?php endif ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
