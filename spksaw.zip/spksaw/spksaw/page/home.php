<style type="text/css">
	h3{
		font-family: arial;
		text-align: justify;
		text-decoration: initial;
	}
</style>
<body bgcolor="Pink">
<h1><p align="center">
<font color="maroon">
	<b>
   	Selamat Datang di Sistem Pendukung Keputusan <br>
	PEMILIHAN APARAT DESA BOAFEO <br>
	Menggunakan Metode Simple Additive Weighting (SAW)
	</b>
</h1> 
</b>
</p>
</font>
<br><br>
<h2>
	<center>
		<img src="image/a.jpg" width="800" height="500">
	</center>
	<br>
<b>Sejarah Singkat Desa Boafeo</b></h2>
<h3>
	<p>
	Desa Boafeo yang awalnya dengan nama Bhoafeo , sebelum masuknya Belanda ke Indonesia Boafeo belum adanya Sistim pemerintahan di Boafeo. Kekuasan tertinggi pada saat itu ada pada para mosalaki  atau tuan tanah dengan kuasa secara turun temurun berdasarkan garis keturunan orang tua laki–laki (Patrilineal). Wilayah kekuasaan para mosalaki berdasarkan hak Ulayat/batas-batas tanah yang  telah diwariskan oleh pendahulu mereka. Tonggak awal berdiri Desa Boafeo yaitu dengan masuknya masa Penjajahan  Belanda di Boafeo dan sekitarnya. <br>Dengan masuknya penjajah Belanda maka ada perlawanan terhadap tindakan penjajahan Belanda yang tidak sesuai dengan budaya setempat oleh beberapa tokoh pemberontak. Tokoh pemberontak yang terkenal    adalah Sato Joto yang mengadakan perlawanan terhadap Penjajah Belanda ( ± 1913 ) sampai akhirnya Ia ditangkap Belanda dan dibuang ke Pulau Jawa. Dengan tertangkapnya Sato Joto ( ± 1916 ) oleh Letnan Geskeber, pemberontakan diwilayah ini padam sehingga tidak ada lagi pemberontakan di wilayah tersebut. <br> Tokoh-tokoh pemberontak yang bersama Sato Joto mengadakan perlawanan terhadap Belanda diantaranya : Wara Mbangga dari Ae Nggaja yang dibuang ke Jawa, Sara Wara dari Boafeo yang ditangkap dan dipenjarahkan di Ende kemudian dibuang Ke Kupang, Mbata Bhato  yang ditangkap dan dipenjarahkan di Sawa Lunto, Nipa Laja (mandor Belanda) diberhentikan karena berkianat terhadap Belanda dan Seto Meo dari Wolokoli (Mbakaondo) Dengan padamnya pemberontakan Belanda membentuk Pemerintahan di wilayah Boafeo dan sekitarnya  Tahun ±  1918 dengan  nama  Distrik  yang berpusat di Boafeo dengan wilayah yang  meliputi Boafeo dan sekitarnya sampai Waka , dengan sebutan “Uzhu Wolomari - Eko Waka” dan Belanda mengangkat Dhae Rea sebagai pemimpin Distrik  yang  pertama dan diganti dengan orang – orang berikutnya. <br> Dimasa inilah Sekolah didirikan (SDK Boafeo sekarang (1922)) yang didirikan oleh Pater Heting. Masa pemerintahan Distrik berakhir yaitu dengan masuknya penjajahan Jepang di wilaya Boafeo pada Tahun -+1942. Sistim pemerentahan Belanda (Distrik) diganti dengan sistim pemerintahan Jepang yaitu Gunco yang berlangsung dari tahun 1942 sampai dengan tahun 1948 atau pada saat masuknya tentara sekutu (NICA) yang memboncengi Belanda. Dan sistim pemerintahan Jepang (Gunco) diganti dengan sistim pemerintahan Belanda yaitu Hamente. Dan pada saat itu Hamente Boafeo digabungkan dengan Hamente Mautenda dengan Ibu Negeri (Ibu Kota) Detu Kajawa (Tahun 1948 – 1953). <br> Perubahan sistim pemerintahan dari Swapraja menjadi Kecamatan (dengan berlakunya UU Nomor 69 Tahun 1958)  Boafeo masuk Kecamatan Detusoko) dan Hamente diganti dengan Koordinator. Dengan perubahan sistim pemerintahan ini Boafeo kembali menjadi wilayah Koordinator  yang terpisah dari Mautenda dengan Nama Koordinator Wilayah Utara yang meliputi Boafeo,Ratesuba,Nabe,Mukusaki, sampai Waka (Eko Ae). <br> Pada Tahun 1963 wilayah Koordinator Boafeo mekar menjadi 2 wilayah yaitu Koordinator Boafeo Selatan dengan pusat administrasi di Boafeo dengan wilayah Boafeo,Nabe,Waka dan Koordinator wilayah Utara dengan pusat administrasi di Ratesuba. Roda pemerentahan terus berjalan hingga pada Tahun 1967  Desa Boafeo dimekarkan menjadi 2 Desa yaitu Desa Boafeo dan Desa Nabe.  Wilayah Desa Boafeo meliputi Boafeo,Wolomari dan Oto Au. Tahun 1998  Desa Boafeo mekar lagi menjadi Dua Desa yaitu Desa Boafeo dan Desa Mbotulaka. <br> Dalam perjalanan sejarah Desa Boafeo yang termasuk dalam wilayah Kecamatan Detusoko, pada Tahun 2000 masuk wilayah Kecamatan Wewaria dan pada Tahun 2001 masuk Kecamatan Maukaro.(Perda Kabupaten Ende No.51 Tahun 2001 dan diresmikan pada tanggal 09 September 2001). <br> <br>
	<b>Kondisi Geografis</b> <br>
	Keadaan wilayah Desa Boafeo terdiri dari Perbukitan dan lembah dengan  ketinggian tempat dari permukaan laut  800 m serta berbatasan dengan : <br>
	Utara	:	Desa Mbotulaka Kecamatan Wewaria. <br>
	Selatan	:	Desa Mbotutenda Kecamatan Ende <br>
	Timur 	:  	Desa Wologai Kecamatan Ende. <br>
	Barat 	: 	Desa Kebirangga Selatan Kec. Maukaro. <br>
	Luas Wilayah 	:	13,4 Km2 . <br>
	Jarak dari ibukota Kabupaten 37 Km dengan waktu tempuh 3 jam dengan    kendaraan. <br>
	Jarak dari ibukota Kecamatan 20 Km dengan waktu tempuh 3 jam dengan   kendaraan. <br>
	Wilayah administrasi Desa Boafeo terdiri dari 2 (dua) dusun, 3 (tiga) RW   dan   8 (delapan) RT. <br>



	</p>
</h3>
