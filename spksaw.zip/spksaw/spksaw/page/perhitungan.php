<div class="row">
	<div class="col-md-12">
	<?php if (isset($_GET["jabatan"])) {
		$sqlKriteria = "";
		$namaKriteria = [];
		$queryKriteria = $connection->query("SELECT a.kd_kriteria, a.nama FROM kriteria a JOIN model b USING(kd_kriteria) WHERE b.kd_jabatan=$_GET[jabatan]");
		while ($kr = $queryKriteria->fetch_assoc()) {
			$sqlKriteria .= "SUM(
				IF(
					c.kd_kriteria=".$kr["kd_kriteria"].",
					IF(c.sifat='max', nilai.nilai/c.normalization, c.normalization/nilai.nilai), 0
				)
			) AS ".strtolower(str_replace(" ", "_", $kr["nama"])).",";
			$namaKriteria[] = strtolower(str_replace(" ", "_", $kr["nama"]));
		}
		$sql = "SELECT
			(SELECT nama FROM pegawai WHERE nip=peg.nip) AS nama,
			(SELECT nip FROM pegawai WHERE nip=peg.nip) AS nip,
			(SELECT tahun_mengajukan FROM pegawai WHERE nip=peg.nip) AS tahun,
			$sqlKriteria
			SUM(
				IF(
						c.sifat = 'max',
						nilai.nilai / c.normalization,
						c.normalization / nilai.nilai
				) * c.bobot
			) AS rangking
		FROM
			nilai
			JOIN pegawai peg USING(nip)
			JOIN (
				SELECT
						nilai.kd_kriteria AS kd_kriteria,
						kriteria.sifat AS sifat,
						(
							SELECT bobot FROM model WHERE kd_kriteria=kriteria.kd_kriteria AND kd_jabatan=jabatan.kd_jabatan
						) AS bobot,
						ROUND(
							IF(kriteria.sifat='max', MAX(nilai.nilai), MIN(nilai.nilai)), 1
						) AS normalization
					FROM nilai
					JOIN kriteria USING(kd_kriteria)
					JOIN jabatan ON kriteria.kd_jabatan=jabatan.kd_jabatan
					WHERE jabatan.kd_jabatan=$_GET[jabatan]
				GROUP BY nilai.kd_kriteria
			) c USING(kd_kriteria)
		WHERE kd_jabatan=$_GET[jabatan]
		GROUP BY nilai.nip
		ORDER BY rangking DESC"; ?>
	  <div class="panel panel-primary">
	      <div class="panel-heading"><h3 class="text-center"><h2 class="text-center"><?php $query = $connection->query("SELECT * FROM jabatan WHERE kd_jabatan=$_GET[jabatan]"); echo $query->fetch_assoc()["nama"]; ?></h2></h3></div>
	      <div class="panel-body">
	          <table class="table table-condensed table-hover">
	              <thead>
	                  <tr>
							<th>NIP</th>
							<th>Nama</th>
							<?php $query = $connection->query("SELECT nama FROM kriteria WHERE kd_jabatan=$_GET[jabatan]"); while($row = $query->fetch_assoc()): ?>
								<th><?=$row["nama"]?></th>
							<?php endwhile ?>
							<th>Nilai</th>
	                  </tr>
	              </thead>
	              <tbody>
					<?php $query = $connection->query($sql); while($row = $query->fetch_assoc()): ?>
					<?php
					$rangking = number_format((float) $row["rangking"], 8, '.', '');
					$q = $connection->query("SELECT nip FROM hasil WHERE nip='$row[nip]' AND kd_jabatan='$_GET[jabatan]' AND tahun='$row[tahun]'");
					if (!$q->num_rows) {
					$connection->query("INSERT INTO hasil VALUES(NULL, '$_GET[jabatan]', '$row[nip]', '".$rangking."', '$row[tahun]')");
					}
					?>
					<tr>
						<td><?=$row["nip"]?></td>
						<td><?=$row["nama"]?></td>
						<?php for($i=0; $i<count($namaKriteria); $i++): ?>
						<th><?=number_format((float) $row[$namaKriteria[$i]], 8, '.', '');?></th>
						<?php endfor ?>
						<td><?=$rangking?></td>
					</tr>
					<?php endwhile;?>
	              </tbody>
	          </table>
	      </div>
	  </div>
	<?php } else { ?>
		<h1>Pegawai belum dipilih...</h1>
	<?php } ?>
	</div>
</div>
