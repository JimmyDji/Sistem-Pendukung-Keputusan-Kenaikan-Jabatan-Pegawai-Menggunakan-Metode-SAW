<?php
require_once "config.php";
if (empty($_SESSION)) {
  header('location: login.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SPK-Pemilihan Aprat Desa</title>
    <style>
        body {
            margin-top: 40px;
        }
        .b{
        	margin-left: 950px;
        }
    </style>
</head>
<body>
    <div class="container">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand" href="#">PENGUMUMAN PEMILIHAN APARAT DESA BOAFEO</a>
                </div>
            </div><!-- /.container-fluid -->
        </nav>
        <div class="row">
            <div class="col-md-12">
							<div class="row">
								<div class="col-md-12">
									<table class="table table-condensed">
			                <thead>
			                    <tr>
			                        <th>No</th>
			                        <th>NIP</th>
            						<th>Nama</th>
            						<th>Jabatan</th>
			                        <th>Nilai</th>
			                        <th>Tahun</th>
			                        <th></th>
			                    </tr>
			                </thead>
			                <tbody>
			                    <?php $no = 1; ?>
			                    <?php if ($query = $connection->query("SELECT b.nama AS jabatan, a.nip, a.nilai, a.tahun, c.nama FROM hasil a JOIN jabatan b USING(kd_jabatan) JOIN pegawai c ON a.nip=c.nip")): ?>
			                        <?php while($row = $query->fetch_assoc()): ?>
			                        <tr>
			                            <td><?=$no++?></td>
              							<td><?=$row["nip"]?></td>
              							<td><?=$row["nama"]?></td>
			                            <td><?=$row["jabatan"]?></td>
			                            <td><?=number_format((float) $row["nilai"], 8, '.', '')?></td>
			                            <td><?=$row['tahun']?></td>
			                        </tr>
			                        <?php endwhile ?>
			                    <?php endif ?>
			                </tbody>
			            </table>
			            <br>
			            <div class="b">
                                <a href="./laporan/cetak.php" class="btn btn-primary" target="blank" style="margin-top: 8px; margin-left: 5px;">CETAK PENGUMUMAN</a><br><br>
                        </div>
					</div>
				</div>
            </div>
        </div>
    </div>
</body>
</html>
