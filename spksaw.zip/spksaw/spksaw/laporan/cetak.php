<?php
error_reporting(0);
$connection = new mysqli("localhost","root","","spk_kenaikan_jabatan");

$content ='

<style type="text/css">
	.tabel{
		border-collapse: collapse;
	}
	.tabel0{
		width: 5%;
	}
	.tabel1{
		width: 15%;
	}
	.tabel2{
		width: 25%;
	}
	.tabel3{
		width: 15%;
	}
	.tabel4{
		width: 10%;
	}
	.ttd{
		text-align: center;
		margin-left: 460px;
		font-size: 14px;
	}
	.tabel th{padding: 8px 5px;  background-color:  #cccccc;   }
	.tabel td{padding: 8px 5px;}
</style>


';

 $content .= '

<page>
<br>
<h1 align="center">Pengumuman Pemilihan Aparat Pegawai <br> Desa Boafeo <br>
</h1>
<br>
<table border="1px" class="tabel" align="center">
<tr>
<th class="tabel0" align="center">No</th>
<th class="tabel1" align="center">NIP</th>
<th class="tabel2" align="center">Nama Pegawai</th>
<th class="tabel3" align="center">Jabatan</th>
<th class="tabel4" align="center">Nilai</th>
<th class="tabel4" align="center">Tahun</th>
</tr>';

if (isset($_POST['cetak'])) {
	$no = 1;
	$query = $connection->query("SELECT b.nama AS jabatan, a.nip, a.nilai, a.tahun, c.nama FROM hasil a JOIN jabatan b USING(kd_jabatan) JOIN pegawai c ON a.nip=c.nip");

	while($row = $query->fetch_assoc()){

	$content .='
		<tr>
			<td align="center">'.$no++.'</td>
			<td>'.$row['nip'].'</td>
			<td>'.$row['nama'].'</td>
			<td>'.$row['jabatan'].'</td>
			<td align="center">'.$row['nilai'].'</td>
			<td align="center">'.$row['tahun'].'</td>
		</tr>
	';	
}
}else{
	$no = 1;
	$query = $connection->query("SELECT b.nama AS jabatan, a.nip, a.nilai, a.tahun, c.nama FROM hasil a JOIN jabatan b USING(kd_jabatan) JOIN pegawai c ON a.nip=c.nip");

	while($row = $query->fetch_assoc()){

	$content .='
		<tr>
			<td align="center">'.$no++.'</td>
			<td>'.$row['nip'].'</td>
			<td>'.$row['nama'].'</td>
			<td>'.$row['jabatan'].'</td>
			<td align="center">'.$row['nilai'].'</td>
			<td align="center">'.$row['tahun'].'</td>
		</tr>
	';
}
}
$content .='
</table>
<br><br>
<br><br>
<div class="ttd">
Mengetahui : 
<br>
Kepala Desa Boafeo <br><br><br><br>
(Quintus Laja) </div>
</page>
    ';

require_once('../assets/html2pdf/html2pdf.class.php');
$html2pdf = new HTML2PDF('P','A4','fr');
$html2pdf->WriteHTML($content);
$html2pdf->Output('exemple.pdf');
?>